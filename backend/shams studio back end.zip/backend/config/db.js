const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const mongoUri = process.env.MONGO_URI;
    const isPlaceholderOrLocal = !mongoUri || 
      mongoUri.includes('<username>') || 
      mongoUri.includes('YOUR_MONGODB_URI') || 
      mongoUri.includes('127.0.0.1') || 
      mongoUri.includes('localhost');

    if (isPlaceholderOrLocal) {
      console.log('ℹ️ MONGO_URI is omitted or using placeholder/local address. Operating in-memory fallback store.');
      return false;
    }
    const conn = await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 2000 });
    console.log(`✅ MongoDB Atlas Connected: ${conn.connection.host}`);
    return true;
  } catch (error) {
    console.warn(`ℹ️ MongoDB Atlas Connection Notice: ${error.message}`);
    return false;
  }
};

/**
 * Checks if Mongoose model is connected to active database
 * @param {Object} model Mongoose model instance
 * @returns {boolean}
 */
const isDbConnected = (model) => {
  return model && model.db && model.db.readyState === 1;
};

module.exports = {
  connectDB,
  isDbConnected,
};

