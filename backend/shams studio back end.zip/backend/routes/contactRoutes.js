const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Contact = require('../models/Contact');
const { isDbConnected } = require('../config/db');
const { isValidEmail, sanitizeString } = require('../utils/validators');
const { protect, adminOnly } = require('../middleware/authMiddleware');

let memoryContacts = [
  {
    _id: 'contact-1',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@enterprise-tech.io',
    phone: '+1 (555) 234-5678',
    message: 'Hello SHAMS STUDIO team! We are looking to develop an AI Video Ad campaign and custom web dashboard for our upcoming Q4 brand refresh.',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
  {
    _id: 'contact-2',
    name: 'Alex Vance',
    email: 'alex@vance-design.com',
    phone: '+44 20 7946 0912',
    message: 'Hi there, loved your work on FinFlow banking UI system. Could you share details regarding your timeline and availability for enterprise UI/UX consulting?',
    createdAt: new Date(Date.now() - 3600000 * 28).toISOString(),
  }
];

/**
 * Safely fetches a Mongoose contact message document by ID or custom _id string
 */
const findContactById = async (id) => {
  if (mongoose.Types.ObjectId.isValid(id)) {
    return await Contact.findById(id);
  }
  return await Contact.findOne({ _id: id });
};

// @route   POST /api/contact
// @desc    Submit contact message from website client
// @access  Public
router.post('/', async (req, res, next) => {
  try {
    const name = sanitizeString(req.body.name);
    const email = sanitizeString(req.body.email);
    const phone = sanitizeString(req.body.phone);
    const message = sanitizeString(req.body.message);

    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and message are required fields',
      });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address',
      });
    }

    const contactData = {
      name,
      email,
      phone: phone || '',
      message,
    };

    if (isDbConnected(Contact)) {
      const contact = await Contact.create(contactData);
      return res.status(201).json({
        success: true,
        message: 'Thank you for contacting SHAMS STUDIO! Your message has been received.',
        data: contact,
      });
    }

    const newMemoryContact = {
      _id: 'contact-' + Date.now(),
      ...contactData,
      createdAt: new Date().toISOString(),
    };
    memoryContacts.unshift(newMemoryContact);

    res.status(201).json({
      success: true,
      message: 'Thank you for contacting SHAMS STUDIO! Your message has been received.',
      data: newMemoryContact,
    });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/contact
// @desc    Get all contact messages (supports ?search=..., ?page=..., ?limit=...)
// @access  Private/Admin
router.get('/', protect, adminOnly, async (req, res, next) => {
  try {
    const { search, page, limit } = req.query;
    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);
    const isPaginated = !isNaN(pageNum) && pageNum > 0 && !isNaN(limitNum) && limitNum > 0;

    if (isDbConnected(Contact)) {
      const query = {};
      if (search) {
        const searchRegex = new RegExp(search.trim(), 'i');
        query.$or = [
          { name: searchRegex },
          { email: searchRegex },
          { phone: searchRegex },
          { message: searchRegex },
        ];
      }

      if (isPaginated) {
        const total = await Contact.countDocuments(query);
        const messages = await Contact.find(query)
          .lean()
          .sort({ createdAt: -1 })
          .skip((pageNum - 1) * limitNum)
          .limit(limitNum);

        return res.json({
          success: true,
          count: messages.length,
          total,
          page: pageNum,
          pages: Math.ceil(total / limitNum),
          data: messages,
        });
      }

      const messages = await Contact.find(query).lean().sort({ createdAt: -1 });
      return res.json({ success: true, count: messages.length, data: messages });
    }

    // Memory fallback store
    let results = [...memoryContacts];
    if (search) {
      const q = search.trim().toLowerCase();
      results = results.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q) ||
          c.phone.toLowerCase().includes(q) ||
          c.message.toLowerCase().includes(q)
      );
    }

    if (isPaginated) {
      const total = results.length;
      const start = (pageNum - 1) * limitNum;
      const paginatedData = results.slice(start, start + limitNum);
      return res.json({
        success: true,
        count: paginatedData.length,
        total,
        page: pageNum,
        pages: Math.ceil(total / limitNum),
        data: paginatedData,
      });
    }

    res.json({ success: true, count: results.length, data: results });
  } catch (error) {
    next(error);
  }
});

// @route   DELETE /api/contact/:id
// @desc    Delete contact message
// @access  Private/Admin
router.delete('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;

    if (isDbConnected(Contact)) {
      const contact = await findContactById(id);
      if (!contact) return res.status(404).json({ success: false, message: 'Message not found' });
      await contact.deleteOne();
      return res.json({ success: true, message: 'Message deleted successfully' });
    }

    const idx = memoryContacts.findIndex((c) => c._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Message not found' });

    memoryContacts.splice(idx, 1);
    res.json({ success: true, message: 'Message deleted successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

