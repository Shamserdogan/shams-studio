const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Portfolio = require('../models/Portfolio');
const { isDbConnected } = require('../config/db');
const { sanitizeString, parseArrayField } = require('../utils/validators');
const { protect, adminOnly } = require('../middleware/authMiddleware');

let memoryPortfolio = [
  {
    _id: 'portfolio-1',
    title: 'Aetheria AI Video Campaign',
    description: 'High-converting 3D neural motion commercial produced for a global luxury cyber-tech brand.',
    category: 'AI Video Ads',
    technologies: ['Sora', 'Midjourney v6', 'ComfyUI', 'After Effects'],
    image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    video: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    liveUrl: 'https://shamsstudio.com/work/aetheria',
    githubUrl: 'https://github.com/shamsstudio/aetheria-campaign',
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
  },
  {
    _id: 'portfolio-2',
    title: 'Nexus Enterprise Dashboard',
    description: 'Real-time telemetry, microservices monitoring, and AI predictive analytics dashboard.',
    category: 'Web Development',
    technologies: ['React 19', 'TypeScript', 'Tailwind CSS', 'Node.js', 'Express', 'D3.js'],
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    video: '',
    liveUrl: 'https://nexus-dashboard.demo.app',
    githubUrl: 'https://github.com/shamsstudio/nexus-dashboard',
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
  },
  {
    _id: 'portfolio-3',
    title: 'FinFlow Banking UI/UX Design System',
    description: 'Ultra-accessible dark & light design system created for next-gen fintech application.',
    category: 'UI/UX Design',
    technologies: ['Figma', 'Design Tokens', 'Tailwind', 'Motion'],
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    video: '',
    liveUrl: 'https://figma.com/@shamsstudio/finflow',
    githubUrl: '',
    createdAt: new Date(Date.now() - 86400000 * 30).toISOString(),
  },
  {
    _id: 'portfolio-4',
    title: 'Global Mesh Enterprise Network Architecture',
    description: 'Zero-trust multi-region cloud infrastructure and automated SD-WAN network setup.',
    category: 'Enterprise Networking',
    technologies: ['Cisco ISO-XE', 'Palo Alto Networks', 'Terraform', 'AWS DirectConnect'],
    image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1200&q=80',
    video: '',
    liveUrl: 'https://shamsstudio.com/solutions/networking',
    githubUrl: 'https://github.com/shamsstudio/network-automation',
    createdAt: new Date(Date.now() - 86400000 * 45).toISOString(),
  },
  {
    _id: 'portfolio-5',
    title: 'CogniBrand AI Content Studio',
    description: 'Automated multi-channel social media asset and AI copywriting platform.',
    category: 'AI Content Creation',
    technologies: ['Gemini 2.5', 'Claude 3.5', 'React', 'Python', 'FastAPI'],
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    video: '',
    liveUrl: 'https://cognibrand.ai',
    githubUrl: 'https://github.com/shamsstudio/cognibrand-ai',
    createdAt: new Date(Date.now() - 86400000 * 60).toISOString(),
  },
];

/**
 * Safely fetches a Mongoose portfolio document by ID or custom _id string
 */
const findPortfolioById = async (id) => {
  if (mongoose.Types.ObjectId.isValid(id)) {
    return await Portfolio.findById(id);
  }
  return await Portfolio.findOne({ _id: id });
};

// @route   GET /api/portfolio
// @desc    Get all portfolio items (supports ?search=..., ?category=..., ?page=..., ?limit=...)
// @access  Public
router.get('/', async (req, res, next) => {
  try {
    const { search, category, page, limit } = req.query;
    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);
    const isPaginated = !isNaN(pageNum) && pageNum > 0 && !isNaN(limitNum) && limitNum > 0;

    if (isDbConnected(Portfolio)) {
      const query = {};
      if (category) {
        query.category = { $regex: new RegExp(`^${category.trim()}$`, 'i') };
      }
      if (search) {
        const searchRegex = new RegExp(search.trim(), 'i');
        query.$or = [
          { title: searchRegex },
          { description: searchRegex },
          { category: searchRegex },
          { technologies: searchRegex },
        ];
      }

      if (isPaginated) {
        const total = await Portfolio.countDocuments(query);
        const items = await Portfolio.find(query)
          .lean()
          .sort({ createdAt: -1 })
          .skip((pageNum - 1) * limitNum)
          .limit(limitNum);

        return res.json({
          success: true,
          count: items.length,
          total,
          page: pageNum,
          pages: Math.ceil(total / limitNum),
          data: items,
        });
      }

      const items = await Portfolio.find(query).lean().sort({ createdAt: -1 });
      return res.json({ success: true, count: items.length, data: items });
    }

    // Memory fallback store
    let results = [...memoryPortfolio];
    if (category) {
      results = results.filter((p) => p.category.toLowerCase() === category.trim().toLowerCase());
    }
    if (search) {
      const q = search.trim().toLowerCase();
      results = results.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          (p.technologies && p.technologies.some((t) => t.toLowerCase().includes(q)))
      );
    }

    if (isPaginated) {
      const total = results.length;
      const start = (pageNum - 1) * limitNum;
      const paginatedData = results.slice(start, start + limitNum);
      return res.json({
        success: true,
        count: paginatedData.length,
        total,
        page: pageNum,
        pages: Math.ceil(total / limitNum),
        data: paginatedData,
      });
    }

    res.json({ success: true, count: results.length, data: results });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/portfolio/:id
// @desc    Get single portfolio item
// @access  Public
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (isDbConnected(Portfolio)) {
      const item = await findPortfolioById(id);
      if (!item) return res.status(404).json({ success: false, message: 'Portfolio project not found' });
      return res.json({ success: true, data: item.toObject ? item.toObject() : item });
    }
    const item = memoryPortfolio.find((p) => p._id === id);
    if (!item) return res.status(404).json({ success: false, message: 'Portfolio project not found' });
    res.json({ success: true, data: item });
  } catch (error) {
    next(error);
  }
});

// @route   POST /api/portfolio
// @desc    Create new portfolio project
// @access  Private/Admin
router.post('/', protect, adminOnly, async (req, res, next) => {
  try {
    const title = sanitizeString(req.body.title);
    const description = sanitizeString(req.body.description);
    const category = sanitizeString(req.body.category);
    const image = sanitizeString(req.body.image);
    const video = sanitizeString(req.body.video);
    const liveUrl = sanitizeString(req.body.liveUrl);
    const githubUrl = sanitizeString(req.body.githubUrl);
    const technologies = parseArrayField(req.body.technologies);

    if (!title || !description) {
      return res.status(400).json({ success: false, message: 'Title and description are required' });
    }

    const projectData = {
      title,
      description,
      category: category || 'Web Development',
      technologies,
      image: image || 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
      video: video || '',
      liveUrl: liveUrl || '',
      githubUrl: githubUrl || '',
    };

    if (isDbConnected(Portfolio)) {
      const item = await Portfolio.create(projectData);
      return res.status(201).json({ success: true, data: item });
    }

    const newItem = {
      _id: 'portfolio-' + Date.now(),
      ...projectData,
      createdAt: new Date().toISOString(),
    };
    memoryPortfolio.unshift(newItem);
    res.status(201).json({ success: true, data: newItem });
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/portfolio/:id
// @desc    Update portfolio project
// @access  Private/Admin
router.put('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, description, category, technologies, image, video, liveUrl, githubUrl } = req.body;

    if (isDbConnected(Portfolio)) {
      let item = await findPortfolioById(id);
      if (!item) return res.status(404).json({ success: false, message: 'Portfolio project not found' });

      if (title) item.title = sanitizeString(title);
      if (description) item.description = sanitizeString(description);
      if (category) item.category = sanitizeString(category);
      if (technologies) item.technologies = parseArrayField(technologies);
      if (image) item.image = sanitizeString(image);
      if (video !== undefined) item.video = sanitizeString(video);
      if (liveUrl !== undefined) item.liveUrl = sanitizeString(liveUrl);
      if (githubUrl !== undefined) item.githubUrl = sanitizeString(githubUrl);

      const updatedItem = await item.save();
      return res.json({ success: true, data: updatedItem });
    }

    const idx = memoryPortfolio.findIndex((p) => p._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Portfolio project not found' });

    memoryPortfolio[idx] = {
      ...memoryPortfolio[idx],
      title: title ? sanitizeString(title) : memoryPortfolio[idx].title,
      description: description ? sanitizeString(description) : memoryPortfolio[idx].description,
      category: category ? sanitizeString(category) : memoryPortfolio[idx].category,
      technologies: technologies ? parseArrayField(technologies) : memoryPortfolio[idx].technologies,
      image: image ? sanitizeString(image) : memoryPortfolio[idx].image,
      video: video !== undefined ? sanitizeString(video) : memoryPortfolio[idx].video,
      liveUrl: liveUrl !== undefined ? sanitizeString(liveUrl) : memoryPortfolio[idx].liveUrl,
      githubUrl: githubUrl !== undefined ? sanitizeString(githubUrl) : memoryPortfolio[idx].githubUrl,
      updatedAt: new Date().toISOString(),
    };

    res.json({ success: true, data: memoryPortfolio[idx] });
  } catch (error) {
    next(error);
  }
});

// @route   DELETE /api/portfolio/:id
// @desc    Delete portfolio project
// @access  Private/Admin
router.delete('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;

    if (isDbConnected(Portfolio)) {
      const item = await findPortfolioById(id);
      if (!item) return res.status(404).json({ success: false, message: 'Portfolio project not found' });
      await item.deleteOne();
      return res.json({ success: true, message: 'Portfolio project deleted successfully' });
    }

    const idx = memoryPortfolio.findIndex((p) => p._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Portfolio project not found' });

    memoryPortfolio.splice(idx, 1);
    res.json({ success: true, message: 'Portfolio project deleted successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

