const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Service = require('../models/Service');
const { isDbConnected } = require('../config/db');
const { sanitizeString, parseArrayField } = require('../utils/validators');
const { protect, adminOnly } = require('../middleware/authMiddleware');

let memoryServices = [
  {
    _id: 'service-1',
    title: 'AI Video Ads',
    subtitle: 'Next-Gen Commercials & Cinematic Motion Production',
    description: 'Transform brand storytelling with photorealistic AI video synthesis, dynamic motion graphics, and ultra-high conversion video advertising campaigns.',
    icon: 'Video',
    image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    video: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    highlights: ['Generative Neural Video', 'Custom Voice Synthesis & Dubbing', 'Multi-Platform Ad Resizing', 'Automated Storyboarding'],
    technologies: ['Runway Gen-3', 'Sora', 'Midjourney', 'After Effects', 'ElevenLabs'],
    createdAt: new Date().toISOString(),
  },
  {
    _id: 'service-2',
    title: 'Web Development',
    subtitle: 'High-Performance Full-Stack Digital Products',
    description: 'Crafting responsive, ultra-fast web applications, SaaS platforms, and enterprise portals with flawless frontend animations and rock-solid REST/GraphQL backends.',
    icon: 'Code',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
    video: '',
    highlights: ['Full-Stack Modern Stack', 'SEO & Performance Optimization', 'API Architecture & DB Sync', 'Vercel / Cloud Run Deployment'],
    technologies: ['React 19', 'TypeScript', 'Next.js / Vite', 'Node.js', 'Express', 'MongoDB Atlas'],
    createdAt: new Date().toISOString(),
  },
  {
    _id: 'service-3',
    title: 'UI/UX Design',
    subtitle: 'Human-Centered Design Systems & Digital Products',
    description: 'Elevate user experience through intuitive workflows, pixel-perfect design systems, interactive prototypes, and accessible user journeys.',
    icon: 'Palette',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    video: '',
    highlights: ['Comprehensive Design Systems', 'Interactive Micro-Animations', 'User Research & Journey Mapping', 'Multi-Theme Contrast Tokens'],
    technologies: ['Figma', 'Framer', 'Tailwind CSS', 'Radix UI', 'Lottie'],
    createdAt: new Date().toISOString(),
  },
  {
    _id: 'service-4',
    title: 'Enterprise Networking',
    subtitle: 'Cloud Infrastructure & High-Availability Network Mesh',
    description: 'Architecting secure, zero-trust cloud infrastructure, software-defined networking, SD-WAN topologies, and multi-region network failover.',
    icon: 'Network',
    image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1200&q=80',
    video: '',
    highlights: ['Zero-Trust Architecture', 'SD-WAN & VPN Networks', '24/7 Telemetry Monitoring', 'Automated Cloud Failover'],
    technologies: ['Cisco', 'Palo Alto', 'AWS / GCP Networking', 'Terraform', 'Docker'],
    createdAt: new Date().toISOString(),
  },
  {
    _id: 'service-5',
    title: 'AI Content Creation',
    subtitle: 'Automated Brand Copywriting & Asset Generation',
    description: 'Empower your marketing suite with automated AI copywriting engines, multi-language asset adaptation, and automated visual content pipelines.',
    icon: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    video: '',
    highlights: ['Custom Fine-Tuned AI Prompts', 'Multi-Channel Brand Consistency', 'Automated Social Content Streams', 'Instant Multilingual Localisation'],
    technologies: ['Gemini 2.5', 'Claude 3.5', 'OpenAI GPT-4o', 'Python API', 'LangChain'],
    createdAt: new Date().toISOString(),
  },
];

/**
 * Safely fetches a Mongoose service document by ID or custom _id string
 */
const findServiceById = async (id) => {
  if (mongoose.Types.ObjectId.isValid(id)) {
    return await Service.findById(id);
  }
  return await Service.findOne({ _id: id });
};

// @route   GET /api/services
// @desc    Get all services (supports ?search=..., ?page=..., ?limit=...)
// @access  Public
router.get('/', async (req, res, next) => {
  try {
    const { search, page, limit } = req.query;
    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);
    const isPaginated = !isNaN(pageNum) && pageNum > 0 && !isNaN(limitNum) && limitNum > 0;

    if (isDbConnected(Service)) {
      const query = {};
      if (search) {
        const searchRegex = new RegExp(search.trim(), 'i');
        query.$or = [
          { title: searchRegex },
          { subtitle: searchRegex },
          { description: searchRegex },
          { highlights: searchRegex },
          { technologies: searchRegex },
        ];
      }

      if (isPaginated) {
        const total = await Service.countDocuments(query);
        const services = await Service.find(query)
          .lean()
          .sort({ createdAt: 1 })
          .skip((pageNum - 1) * limitNum)
          .limit(limitNum);

        return res.json({
          success: true,
          count: services.length,
          total,
          page: pageNum,
          pages: Math.ceil(total / limitNum),
          data: services,
        });
      }

      const services = await Service.find(query).lean().sort({ createdAt: 1 });
      return res.json({ success: true, count: services.length, data: services });
    }

    // Memory fallback store
    let results = [...memoryServices];
    if (search) {
      const q = search.trim().toLowerCase();
      results = results.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          (s.subtitle && s.subtitle.toLowerCase().includes(q)) ||
          s.description.toLowerCase().includes(q) ||
          (s.highlights && s.highlights.some((h) => h.toLowerCase().includes(q))) ||
          (s.technologies && s.technologies.some((t) => t.toLowerCase().includes(q)))
      );
    }

    if (isPaginated) {
      const total = results.length;
      const start = (pageNum - 1) * limitNum;
      const paginatedData = results.slice(start, start + limitNum);
      return res.json({
        success: true,
        count: paginatedData.length,
        total,
        page: pageNum,
        pages: Math.ceil(total / limitNum),
        data: paginatedData,
      });
    }

    res.json({ success: true, count: results.length, data: results });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/services/:id
// @desc    Get single service by ID
// @access  Public
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (isDbConnected(Service)) {
      const service = await findServiceById(id);
      if (!service) return res.status(404).json({ success: false, message: 'Service not found' });
      return res.json({ success: true, data: service.toObject ? service.toObject() : service });
    }
    const service = memoryServices.find((s) => s._id === id);
    if (!service) return res.status(404).json({ success: false, message: 'Service not found' });
    res.json({ success: true, data: service });
  } catch (error) {
    next(error);
  }
});

// @route   POST /api/services
// @desc    Create new service
// @access  Private/Admin
router.post('/', protect, adminOnly, async (req, res, next) => {
  try {
    const title = sanitizeString(req.body.title);
    const subtitle = sanitizeString(req.body.subtitle);
    const description = sanitizeString(req.body.description);
    const icon = sanitizeString(req.body.icon);
    const image = sanitizeString(req.body.image);
    const video = sanitizeString(req.body.video);
    const highlights = parseArrayField(req.body.highlights);
    const technologies = parseArrayField(req.body.technologies);

    if (!title || !description) {
      return res.status(400).json({ success: false, message: 'Title and description are required' });
    }

    const serviceData = {
      title,
      subtitle: subtitle || '',
      description,
      icon: icon || 'Sparkles',
      image: image || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      video: video || '',
      highlights,
      technologies,
    };

    if (isDbConnected(Service)) {
      const service = await Service.create(serviceData);
      return res.status(201).json({ success: true, data: service });
    }

    const newService = {
      _id: 'service-' + Date.now(),
      ...serviceData,
      createdAt: new Date().toISOString(),
    };
    memoryServices.push(newService);
    res.status(201).json({ success: true, data: newService });
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/services/:id
// @desc    Update service
// @access  Private/Admin
router.put('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, subtitle, description, icon, image, video, highlights, technologies } = req.body;

    if (isDbConnected(Service)) {
      let service = await findServiceById(id);
      if (!service) return res.status(404).json({ success: false, message: 'Service not found' });

      if (title) service.title = sanitizeString(title);
      if (subtitle !== undefined) service.subtitle = sanitizeString(subtitle);
      if (description) service.description = sanitizeString(description);
      if (icon) service.icon = sanitizeString(icon);
      if (image) service.image = sanitizeString(image);
      if (video !== undefined) service.video = sanitizeString(video);
      if (highlights) service.highlights = parseArrayField(highlights);
      if (technologies) service.technologies = parseArrayField(technologies);

      const updatedService = await service.save();
      return res.json({ success: true, data: updatedService });
    }

    const idx = memoryServices.findIndex((s) => s._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Service not found' });

    memoryServices[idx] = {
      ...memoryServices[idx],
      title: title ? sanitizeString(title) : memoryServices[idx].title,
      subtitle: subtitle !== undefined ? sanitizeString(subtitle) : memoryServices[idx].subtitle,
      description: description ? sanitizeString(description) : memoryServices[idx].description,
      icon: icon ? sanitizeString(icon) : memoryServices[idx].icon,
      image: image ? sanitizeString(image) : memoryServices[idx].image,
      video: video !== undefined ? sanitizeString(video) : memoryServices[idx].video,
      highlights: highlights ? parseArrayField(highlights) : memoryServices[idx].highlights,
      technologies: technologies ? parseArrayField(technologies) : memoryServices[idx].technologies,
      updatedAt: new Date().toISOString(),
    };

    res.json({ success: true, data: memoryServices[idx] });
  } catch (error) {
    next(error);
  }
});

// @route   DELETE /api/services/:id
// @desc    Delete service
// @access  Private/Admin
router.delete('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;

    if (isDbConnected(Service)) {
      const service = await findServiceById(id);
      if (!service) return res.status(404).json({ success: false, message: 'Service not found' });
      await service.deleteOne();
      return res.json({ success: true, message: 'Service removed successfully' });
    }

    const idx = memoryServices.findIndex((s) => s._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Service not found' });

    memoryServices.splice(idx, 1);
    res.json({ success: true, message: 'Service removed successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

