const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Blog = require('../models/Blog');
const { isDbConnected } = require('../config/db');
const { sanitizeString, parseArrayField } = require('../utils/validators');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// Seed/Memory fallback data for Blogs if DB not connected or empty
let memoryBlogs = [
  {
    _id: 'blog-1',
    title: 'The Future of AI Video Production in Digital Marketing',
    description: 'Explore how generative AI models are revolutionizing high-end video ads and motion design for enterprise brands.',
    content: `Artificial intelligence is fundamentally reshaping how creative studios conceptualize and deliver visual marketing. From neural style transfer to text-to-video generation, studios can now produce photorealistic video advertisements in a fraction of the traditional timeline.\n\nAt SHAMS STUDIO, we leverage cutting-edge AI workflows to create captivating video sequences that boost engagement rates by up to 300%. Here is how enterprise brands can harness this tech today...`,
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    category: 'AI Video Ads',
    tags: ['AI', 'Video Production', 'Marketing', 'Automation'],
    author: 'SHAMS STUDIO',
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    _id: 'blog-2',
    title: 'Building Scalable Full-Stack Web Platforms with React & Node',
    description: 'Key architectural choices for crafting high-performance, ultra-responsive web applications with dynamic backend APIs.',
    content: `Modern web design requires a harmony between sleek visual presentation and rock-solid server performance. By combining React, Express, MongoDB Atlas, and modern animation libraries, we deliver seamless experiences that scale effortlessly.\n\nIn this article, we break down best practices for API security, response caching, and dynamic state management...`,
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
    category: 'Web Development',
    tags: ['React', 'Node.js', 'MongoDB', 'Architecture'],
    author: 'SHAMS STUDIO',
    createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
  },
  {
    _id: 'blog-3',
    title: 'UI/UX Design Systems for Enterprise Scale',
    description: 'How a disciplined design system eliminates visual debt, boosts developer velocity, and delights end users.',
    content: `Design systems are no longer just component libraries—they are the foundational design language of modern digital products. By establishing consistent typographic scales, mathematical spacing grids, and fluid dark/light contrast rules, studios build scalable, accessible UI/UX systems.`,
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    category: 'UI/UX Design',
    tags: ['UI/UX', 'Design Systems', 'Figma', 'Tailwind CSS'],
    author: 'SHAMS STUDIO',
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
  },
];

/**
 * Safely fetches a Mongoose document by ID or custom _id string without throwing CastError
 */
const findBlogById = async (id) => {
  if (mongoose.Types.ObjectId.isValid(id)) {
    return await Blog.findById(id);
  }
  return await Blog.findOne({ _id: id });
};

// @route   GET /api/blogs
// @desc    Get all blogs (supports ?search=..., ?category=..., ?page=..., ?limit=...)
// @access  Public
router.get('/', async (req, res, next) => {
  try {
    const { search, category, page, limit } = req.query;
    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);
    const isPaginated = !isNaN(pageNum) && pageNum > 0 && !isNaN(limitNum) && limitNum > 0;

    if (isDbConnected(Blog)) {
      const query = {};
      if (category) {
        query.category = { $regex: new RegExp(`^${category.trim()}$`, 'i') };
      }
      if (search) {
        const searchRegex = new RegExp(search.trim(), 'i');
        query.$or = [
          { title: searchRegex },
          { description: searchRegex },
          { content: searchRegex },
          { category: searchRegex },
        ];
      }

      if (isPaginated) {
        const total = await Blog.countDocuments(query);
        const blogs = await Blog.find(query)
          .lean()
          .sort({ createdAt: -1 })
          .skip((pageNum - 1) * limitNum)
          .limit(limitNum);

        return res.json({
          success: true,
          count: blogs.length,
          total,
          page: pageNum,
          pages: Math.ceil(total / limitNum),
          data: blogs,
        });
      }

      const blogs = await Blog.find(query).lean().sort({ createdAt: -1 });
      return res.json({ success: true, count: blogs.length, data: blogs });
    }

    // Memory fallback store with search & category filtering
    let results = [...memoryBlogs];
    if (category) {
      results = results.filter((b) => b.category.toLowerCase() === category.trim().toLowerCase());
    }
    if (search) {
      const q = search.trim().toLowerCase();
      results = results.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.description.toLowerCase().includes(q) ||
          b.content.toLowerCase().includes(q) ||
          b.category.toLowerCase().includes(q)
      );
    }

    if (isPaginated) {
      const total = results.length;
      const start = (pageNum - 1) * limitNum;
      const paginatedData = results.slice(start, start + limitNum);
      return res.json({
        success: true,
        count: paginatedData.length,
        total,
        page: pageNum,
        pages: Math.ceil(total / limitNum),
        data: paginatedData,
      });
    }

    res.json({ success: true, count: results.length, data: results });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/blogs/:id
// @desc    Get single blog by ID
// @access  Public
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (isDbConnected(Blog)) {
      const blog = await findBlogById(id);
      if (!blog) return res.status(404).json({ success: false, message: 'Blog not found' });
      return res.json({ success: true, data: blog.toObject ? blog.toObject() : blog });
    }
    const blog = memoryBlogs.find((b) => b._id === id);
    if (!blog) return res.status(404).json({ success: false, message: 'Blog not found' });
    res.json({ success: true, data: blog });
  } catch (error) {
    next(error);
  }
});

// @route   POST /api/blogs
// @desc    Create a new blog
// @access  Private/Admin
router.post('/', protect, adminOnly, async (req, res, next) => {
  try {
    const title = sanitizeString(req.body.title);
    const description = sanitizeString(req.body.description);
    const content = sanitizeString(req.body.content);
    const image = sanitizeString(req.body.image);
    const category = sanitizeString(req.body.category);
    const author = sanitizeString(req.body.author);
    const tags = parseArrayField(req.body.tags);

    if (!title || !description || !content) {
      return res.status(400).json({ success: false, message: 'Title, description, and content are required' });
    }

    const blogData = {
      title,
      description,
      content,
      image: image || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      category: category || 'General',
      tags,
      author: author || 'SHAMS STUDIO',
    };

    if (isDbConnected(Blog)) {
      const blog = await Blog.create(blogData);
      return res.status(201).json({ success: true, data: blog });
    }

    const newMemoryBlog = {
      _id: 'blog-' + Date.now(),
      ...blogData,
      createdAt: new Date().toISOString(),
    };
    memoryBlogs.unshift(newMemoryBlog);
    res.status(201).json({ success: true, data: newMemoryBlog });
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/blogs/:id
// @desc    Update blog
// @access  Private/Admin
router.put('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, description, content, image, category, tags, author } = req.body;

    if (isDbConnected(Blog)) {
      let blog = await findBlogById(id);
      if (!blog) return res.status(404).json({ success: false, message: 'Blog not found' });

      if (title) blog.title = sanitizeString(title);
      if (description) blog.description = sanitizeString(description);
      if (content) blog.content = sanitizeString(content);
      if (image) blog.image = sanitizeString(image);
      if (category) blog.category = sanitizeString(category);
      if (tags) blog.tags = parseArrayField(tags);
      if (author) blog.author = sanitizeString(author);

      const updatedBlog = await blog.save();
      return res.json({ success: true, data: updatedBlog });
    }

    const idx = memoryBlogs.findIndex((b) => b._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Blog not found' });

    memoryBlogs[idx] = {
      ...memoryBlogs[idx],
      title: title ? sanitizeString(title) : memoryBlogs[idx].title,
      description: description ? sanitizeString(description) : memoryBlogs[idx].description,
      content: content ? sanitizeString(content) : memoryBlogs[idx].content,
      image: image ? sanitizeString(image) : memoryBlogs[idx].image,
      category: category ? sanitizeString(category) : memoryBlogs[idx].category,
      tags: tags ? parseArrayField(tags) : memoryBlogs[idx].tags,
      author: author ? sanitizeString(author) : memoryBlogs[idx].author,
      updatedAt: new Date().toISOString(),
    };

    res.json({ success: true, data: memoryBlogs[idx] });
  } catch (error) {
    next(error);
  }
});

// @route   DELETE /api/blogs/:id
// @desc    Delete blog
// @access  Private/Admin
router.delete('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const { id } = req.params;

    if (isDbConnected(Blog)) {
      const blog = await findBlogById(id);
      if (!blog) return res.status(404).json({ success: false, message: 'Blog not found' });
      await blog.deleteOne();
      return res.json({ success: true, message: 'Blog removed successfully' });
    }

    const idx = memoryBlogs.findIndex((b) => b._id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Blog not found' });

    memoryBlogs.splice(idx, 1);
    res.json({ success: true, message: 'Blog removed successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

