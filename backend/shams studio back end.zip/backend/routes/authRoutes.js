const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { isDbConnected } = require('../config/db');
const { sanitizeString, isValidEmail } = require('../utils/validators');
const { protect } = require('../middleware/authMiddleware');

const JWT_SECRET = () => process.env.JWT_SECRET || 'shams_studio_jwt_secret_key_2026_change_this_in_production';

// Generate JWT Token
const generateToken = (id, role, name, email) => {
  return jwt.sign({ id, role, name, email }, JWT_SECRET(), {
    expiresIn: '7d',
  });
};

// @route   POST /api/auth/login
// @desc    Authenticate admin & get token
// @access  Public
router.post('/login', async (req, res, next) => {
  try {
    const rawEmail = sanitizeString(req.body.email);
    const password = sanitizeString(req.body.password);

    if (!rawEmail || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email and password' });
    }

    const email = rawEmail.toLowerCase();

    if (!isValidEmail(email)) {
      return res.status(400).json({ success: false, message: 'Please enter a valid email address' });
    }

    // Default admin fallback credentials check if DB not populated or connected
    const defaultEmail = (process.env.ADMIN_EMAIL || 'admin@shamsstudio.com').toLowerCase();
    const defaultPass = process.env.ADMIN_PASSWORD || 'admin123456';

    let user = null;
    if (isDbConnected(User)) {
      user = await User.findOne({ email });
    }

    if (user) {
      const isMatch = await user.matchPassword(password);
      if (!isMatch) {
        return res.status(401).json({ success: false, message: 'Invalid credentials' });
      }
      const token = generateToken(user._id, user.role, user.name, user.email);
      return res.json({
        success: true,
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      });
    }

    // Check default admin credential fallback
    if (email === defaultEmail && password === defaultPass) {
      const token = generateToken('admin-default-id', 'admin', 'Shams Admin', defaultEmail);
      return res.json({
        success: true,
        token,
        user: {
          id: 'admin-default-id',
          name: 'Shams Admin',
          email: defaultEmail,
          role: 'admin',
        },
      });
    }

    return res.status(401).json({ success: false, message: 'Invalid email or password' });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/auth/me
// @desc    Get current user profile
// @access  Private
router.get('/me', protect, async (req, res) => {
  res.json({
    success: true,
    user: req.user,
  });
});

// @route   POST /api/auth/verify
// @desc    Verify current JWT token
// @access  Private
router.post('/verify', protect, async (req, res) => {
  res.json({
    success: true,
    valid: true,
    user: req.user,
  });
});

// @route   PUT /api/auth/profile
// @desc    Update admin profile, email, or password
// @access  Private
router.put('/profile', protect, async (req, res, next) => {
  try {
    const { name, email, newPassword, currentPassword } = req.body;

    if (isDbConnected(User) && req.user.id !== 'admin-default-id') {
      const user = await User.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      if (currentPassword && !(await user.matchPassword(currentPassword))) {
        return res.status(400).json({ success: false, message: 'Current password is incorrect' });
      }

      if (name) user.name = sanitizeString(name);
      if (email && isValidEmail(email)) user.email = sanitizeString(email).toLowerCase();
      if (newPassword && newPassword.length >= 6) user.password = newPassword;

      await user.save();

      const token = generateToken(user._id, user.role, user.name, user.email);
      return res.json({
        success: true,
        message: 'Profile updated successfully',
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      });
    }

    // In-memory / default admin update response
    const updatedName = name ? sanitizeString(name) : req.user.name;
    const updatedEmail = email && isValidEmail(email) ? sanitizeString(email).toLowerCase() : req.user.email;
    const token = generateToken(req.user.id, req.user.role, updatedName, updatedEmail);

    res.json({
      success: true,
      message: 'Profile updated successfully',
      token,
      user: {
        id: req.user.id,
        name: updatedName,
        email: updatedEmail,
        role: req.user.role,
      },
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
